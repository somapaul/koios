# koios
This project is a machine learning module for Python. The primary purpose of the 
project is to provide a portable implementation of a neural network.

In Greek mythology, Koios (or Coeus) is the Titan god of intellect, the
inquisitve mind, and foresight.
