def koios():
    print('Hello, Koios!')
