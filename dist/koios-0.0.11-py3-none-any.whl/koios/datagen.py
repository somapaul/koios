# functions for generating data


# generate linearly separable data
def linsep(_row,col,_min,_max):
    